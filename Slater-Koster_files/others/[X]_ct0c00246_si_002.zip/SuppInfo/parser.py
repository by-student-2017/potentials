'''
Created on Oct 21, 2019

Parser for trajectories with electron/exciton transfer couplings.
Each trajectory is assumed to consist of pairs of geometry (*.xyz) files and
hamiltonian (*.xvg) files. From these, the coordinates of the sites and pairs of
sites, as well as the corresponding couplings/site energies are read out.

@author: mila
'''

import os
import numpy as np
import itertools
#from itertools import repeat
from itertools import combinations as comb
from itertools import combinations_with_replacement as comb_replace

def grouper(iterable, n, fillvalue = None):
    """
    Reads chunks of n lines from iterable. Fills missing lines at the end with fillvalue.
    Taken from the recipes in the itertools docs.
    """
    args = [iter(iterable)] * n
    return itertools.zip_longest(*args, fillvalue=fillvalue)


class Parser(object):
    '''
    Parser for trajectories.
    '''


    def __init__(self, separate = True, nonzero_only = True):
        '''
        Separate sets the behavior regarding site energies. If separate is false,
        site energies will be read out along with couplings, to be learned together.
        nonzero_only filters out all pairs where the coupling is 0 during parsing
        so they don't waste memory.
        '''
        self.separate = separate
        self.nonzero_only = nonzero_only
        self.ele_to_chg = {"H":1, "C":6}

    def parse(self, path, n_atoms_per_mol, n_mols, cutoff = None, step_increment = 1, offset = 0):
        '''
        Takes a path and some metadata (how many atoms per site, how many sites
        in the system) about the trajectory and returns the nuclear charges of
        one site (all sites assumed identical), as well as coordinates of pairs
        of sites and the corresponding couplings, and if site energies are parsed
        sepately, also site coordinates and site energies.
        '''

        pair_coords = []
        couplings = []
        site_coords = []
        site_energies = []
        nuc_chg = None

        geoms = []
        coups = []
        for f in os.listdir(path):
            if ".xyz" in f[-4:]:
                geoms.append(f)
            elif ".xvg" in f[-4:]:
                coups.append(f)
        geoms.sort()
        coups.sort()

        for geom_f, coup_f in zip(geoms,coups):
            #print(f"parsing files {geom_f}, {coup_f}")
            f_nuc_chg, f_coords, f_coups, f_site_coords, f_site_energies = self.parse_traj(
                os.path.join(path, geom_f), os.path.join(path, coup_f),
                n_atoms_per_mol, n_mols, cutoff, step_increment, offset
                )

            if nuc_chg is not None:
                # assert sites are identical across files
                assert (f_nuc_chg == nuc_chg).all()
            else:
                # take nuclear charges from first file
                nuc_chg = f_nuc_chg

            pair_coords.extend(f_coords)
            couplings.extend(f_coups)

            if self.separate:
                site_coords.extend(f_site_coords)
                site_energies.extend(f_site_energies)


        return np.concatenate((nuc_chg, nuc_chg)), np.asarray(pair_coords), np.asarray(couplings), np.asarray(nuc_chg), np.asarray(site_coords), np.asarray(site_energies)


    def parse_traj(self, geom_f, coup_f, n_atoms_per_mol, n_mols, cutoff, step_increment, offset):

        if not self.separate:
            energies_together = True
        else:
            energies_together = False

        nuc_chg, coords, n_steps = self.parse_geom(geom_f, n_atoms_per_mol, n_mols,
                                                   cutoff, step_increment, offset)

        pair_coords = self.get_all_pairs(coords, n_steps, energies_together)

        couplings, site_energies= self.parse_xvg(coup_f, n_mols, cutoff, step_increment, offset, energies_together)

        if self.nonzero_only:
            pair_coords, couplings = self.filter_nonzero(pair_coords, couplings)

        return nuc_chg, pair_coords, couplings, coords.reshape(n_steps*n_mols, n_atoms_per_mol, 3), site_energies

    def filter_nonzero(self, pair_coords, couplings):
        couplings_a = np.asarray(couplings)
        pair_coords_a = np.asarray(pair_coords)
        pair_coords_a = pair_coords_a[np.nonzero(couplings_a)]
        couplings_a = couplings_a[np.nonzero(couplings_a)]
        couplings = [i for i in couplings_a]
        pair_coords = [i for i in pair_coords_a]
        return pair_coords, couplings


    def parse_geom(self, geom_f, n_atoms_per_mol, n_mols, cutoff, step_increment, offset):

        with open(geom_f) as f:
            atom_count = int(f.readline().rstrip())
            assert n_atoms_per_mol*n_mols == atom_count, f"number of atoms per mol or number of mols does not match given values! {n_atoms_per_mol}*{n_mols} != {atom_count}"
            nuc_chg = np.empty(shape=(n_atoms_per_mol,), dtype = np.int_)
            all_step_coords =  []

            lines_per_step = atom_count + 2
            f.seek(0)
            for step_idx, lines in enumerate(grouper(f, lines_per_step, '')):
                #Alternative End Conditions
                if not lines[0].strip():
                    break # Whitespace at EOF
                if cutoff is not None and step_idx ==cutoff:
                    break # Cutoff
                if (step_idx+offset) % step_increment != 0:
                    continue # read out only every n-th step

                firststep = True
                step_lines = (lines[i] for i in range(2, lines_per_step))

                step_coords = np.empty(shape=(n_mols, n_atoms_per_mol, 3))

                for mol_idx, mol_lines in enumerate(grouper(step_lines, n_atoms_per_mol, '')):
                    for at_idx, at_line in enumerate(mol_lines):
                        at_line = at_line.rstrip().split()
                        if firststep == True and mol_idx == 0:
                            nuc_chg[at_idx] = self.ele_to_chg[at_line[0]]
                        else:
                            assert nuc_chg[at_idx] == self.ele_to_chg[at_line[0]], f"parsing error: atom {at_idx} changed type from {nuc_chg[at_idx]} to {self.ele_to_chg[at_line[0]]}!"
                        step_coords[mol_idx, at_idx] = np.asarray([float(at_line[i]) for i in range(1,len(at_line))])
                all_step_coords.append(step_coords)
                firststep = False

            coords = np.stack(all_step_coords)
            n_steps = len(all_step_coords)

        return nuc_chg, coords, n_steps

    def get_all_pairs(self, coords, n_steps, energies_together):
        all_pairs = []
        for step in range(n_steps):
            all_pairs.extend(self.get_step_pairs(coords[step], energies_together))

        return all_pairs

    def get_step_pairs(self, step_coords, energies_together):
        n_mols = step_coords.shape[0]
        if not energies_together:
            return [np.vstack([step_coords[i], step_coords[j]]) for i,j in comb(range(n_mols), 2)]
        else:
            return [np.vstack([step_coords[i], step_coords[j]]) for i,j in comb_replace(range(n_mols), 2)]

    def parse_couplings(self, coup_f, cutoff, step_increment, energies_together):
        couplings = []
        with open(coup_f) as f:
            l_cnt = 0
            for l in f:
                if cutoff is not None and l_cnt ==cutoff:
                    break
                elif l_cnt % step_increment != 0:
                    l_cnt +=1
                    continue
                else:
                    l_cnt +=1
                    l_cl = [float(_) for _ in l.strip().split()]
                    l_cl.pop(0) # remove time step index
                    if not energies_together:
                        couplings.extend([i for i in l_cl if i<1]) # just discard all values >1 (orbital energies)
                    else:
                        couplings.extend(l_cl)
        return couplings

    def parse_sites(self, coup_f, cutoff, step_increment):
        sites = []
        with open(coup_f) as f:
            l_cnt = 0
            for l in f:
                if cutoff is not None and l_cnt == cutoff:
                    break
                elif l_cnt %step_increment != 0:
                    l_cnt += 1
                    continue
                else:
                    l_cnt +=1
                    l_cl = [float(_) for _ in l.strip().split()]
                    l_cl.pop(0)
                    sites.extend([i for i in l_cl if i>1])
        return sites

    def parse_xvg(self, coup_f, n_mols, cutoff, step_increment, offset, energies_together):
        couplings = []
        energies = []

        with open(coup_f) as f:
            for idx, l in enumerate(f):
                if cutoff is not None and idx == cutoff:
                    break
                elif (idx+offset) % step_increment != 0:
                    continue
                else:
                    l_cont = l.rstrip().split()
                    ham = np.empty(n_mols*n_mols).reshape(n_mols, n_mols)
                    ham[np.triu_indices(n_mols)] = np.asarray(l_cont[1:])
                    if energies_together:
                        couplings.extend(ham[np.triu_indices_from(ham)])
                    else:
                        couplings.extend(ham[np.triu_indices_from(ham, 1)])
                        if self.separate:
                            energies.extend(np.diag(ham))
        return couplings, energies



if __name__ == "__main__":
    parser=Parser()
    c_nuc_chg, c_coords, c_coup, c_site_coords, s_sites = parser.parse("./tests/test_traj",
                                                            24, 30, cutoff=None,
                                                            step_increment=10)
    print(len(c_nuc_chg), len(c_coords), len(c_coup), len(c_site_coords), len(s_sites))
